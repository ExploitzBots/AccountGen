![AccGenBot](https://telegra.ph/file/50ad5f833a34471393384.png) 

# AccGenBot
A Simple Multi-AccGenBot Source Code Made With Python [Telethon]

# Features
* [x] You can add 4 types of Accounts
* [x] Customisable
* [x] Channel Verification Support

# Hits Formatting
Please Edit All `Hits` File And Your Own Hits.

```
email@email.com:password
email@email.com:password
```
# My Devs
➥ [SoulHackz](https://t.me/SoulHackz)

# Configs
```
TOKEN = Bot Token Obtained From @BotFather
APP_HASH = Your Api Hash.
API_ID = Your Api ID.
CHANNEL_USERNAME = Username Of The Channel You Wanna Check Before User Generates Account.
CHANNEL_URL = Url Of The Same Channel
OWNER_ID = Your ID (Owner) Get From Any Bot.
```

# Deploy
[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/SoulHackz/AccGenBot)

# Licence
[![GNU GPLv3 Image](https://www.gnu.org/graphics/gplv3-127x51.png)](http://www.gnu.org/licenses/gpl-3.0.en.html)  
